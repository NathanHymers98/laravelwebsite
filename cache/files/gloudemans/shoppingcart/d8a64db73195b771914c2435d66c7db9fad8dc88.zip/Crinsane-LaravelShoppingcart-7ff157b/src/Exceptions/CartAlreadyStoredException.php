<?php

namespace Gloudemans\Shoppingcart\Exceptions;

use RuntimeException;

class CartAlreadyStoredException extends RuntimeException {}